data:extend({
    {
        type = "recipe-category",
        name = "mohole"
    }
})